# CareCircle - caring together

A shared, passcode-based healthcare ecosystem where an elderly person, their caretakers and their family manage medicines, appointments and daily routines together, **with the elder always in control**.

## Run it (no installs needed)

Requires Python 3.8+ only. No pip, no npm.

```bash
python3 server.py            # open http://localhost:8000
python3 server.py --reset    # wipe data and re-seed the demo circle
```

Demo passcodes: **Elder 1111 · Caretaker 2222 · Family 3333 / 4444**

Files: `server.py` (API, scheduler, email engine, SQLite) and `index.html` (the whole UI).

## Real email (optional)

Without SMTP settings, every email is generated and shown in **Activity → Emails sent** (dry run), which is ideal for demos. For real delivery (Gmail example, use an App Password):

```bash
SMTP_HOST=smtp.gmail.com SMTP_PORT=587 SMTP_USER=you@gmail.com \
SMTP_PASS=your-app-password SMTP_FROM="CareCircle <you@gmail.com>" python3 server.py
```

Then open **Circle → Edit** and put real email addresses on the demo members (addresses ending in `@example.com` are never sent).

## What makes it more than a reminder app

| Idea | How it works |
|---|---|
| **Elder in control** | Only the elder invites/removes people and grants "can edit" per person. Every change by anyone else is logged and emailed to the elder. |
| **Escalation ladder** | 10 min before: nudge elder. 30 min late: elder + caretakers. 60 min late: family joins. Configurable via `UPCOMING_MIN`, `GRACE_MIN`, `ESCALATE_MIN`. |
| **Role-based passcodes** | Elder / caretaker / family roles. Passcodes are visible only to the elder. |
| **Elder mode** | One tap: larger text, simplified navigation, giant "I took it" button, **Read my day** voice summary. |
| **SOS with medical snapshot** | One button emails the whole circle conditions, allergies, blood group, doctor and recent doses. |
| **Wellbeing check-in** | Daily mood tap. A low score alerts caretakers and family. |
| **Smart insights** | 30-day adherence heatmap, per-medicine and time-of-day adherence, week-over-week trend, late-dose detection, streaks, plain-language suggestions. |
| **Refill prediction** | Pill counts decrease as doses are logged; low stock triggers an email to everyone. |
| **Appointment prep** | "Questions for the doctor" travel inside the 24h and 2h reminder emails. |
| **Doctor visit summary** | One-click printable/PDF health summary (medicines, adherence, observations, visits). |
| **Mark on behalf** | A caretaker or family member can log a dose for the elder; it is attributed ("by Anitha"). |

## 3-minute demo script

1. Sign in as **Elder (1111)**: show Today, the big next-dose card, Elder mode toggle, 🔊 Read my day.
2. **Activity → Emails sent**: the seeded missed eye-drop dose already triggered elder, caretaker and family escalation emails.
3. Sign in as **Caretaker (2222)**: add a medicine. Switch back to the elder and show the "updated your care plan" email and change log.
4. Sign in as **Family (3333)**: edit buttons are absent (view only). Mark the missed dose as taken on the elder's behalf.
5. **Insights**: heatmap, smart suggestions, then **Doctor visit summary**.
6. Press **SOS** to show the medical-snapshot email going to the whole circle.

## Notes

- Reminders are checked every 30 seconds by a background thread; each email is de-duplicated per person per event.
- Data lives in `carecircle.db` (SQLite). The UI polls every 30s on the Today and Activity tabs.
- Passcodes are stored as plain text for demo simplicity; for production, hash them and add HTTPS and rate limiting.
